import { useRef   } from "react";
import { Link, Redirect } from "react-router-dom";
import "./Signup.scss";



function Signup (){
    const userName = useRef()
    const userPassword = useRef()
    const userPhone = useRef()
    return (
        <>  <div className="login">
             <div className="login__box">
                            <h1 className="login__title">Signup</h1>
                            <form className="login__form" method="POST">
                            <input type="text" ref={userName} className="login__input" placeholder="your name"/>
                            <input type="number" className="login__input" ref={userPassword} placeholder="your password"/>
                            <input type="number" className="login__input" ref={userPhone} placeholder="your phone"/>
                            <button onClick={async (e) => {
                                e.preventDefault()
                                // const formData = new FormData()
                                //  formData.append("username", userName.current.value)
                                //  formData.append("password", userPassword.current.value)
                                 await fetch("http://localhost:4000/reg", {
                                     method: 'POST',
                                     body: JSON.stringify({
                                         username: userName.current.value,
                                         password: userPassword.current.value,
                                         phone:userPhone.current.value 
                                     }),
                                     headers: {
                                         "Content-Type": "application/json"
                                     }
                                     
                                 })
                                 return <Redirect to="/"></Redirect>
                            }} type="submit" className="login-btn"  >
                                Submit
                            </button >

                            </form>
                            <Link className="login-text" to="/login">
                                Login
                            </Link>

                        </div>

        </div>
        </>
    )
}
export default Signup