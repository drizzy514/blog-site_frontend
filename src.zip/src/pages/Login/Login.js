import {  useRef } from "react";
import { Link, Redirect } from "react-router-dom";
import "./Login.scss";
function Login () {


    const userName = useRef()
    const userPassword = useRef()
    return (
                <>
                    <div className="login">
                        <div>

                        <div className="login__box">
                            <h1 className="login__title">Login </h1>
                            <form className="login__form" method="post" >
                            <input type="text" ref={userName}  className="login__input" placeholder="your name"/>
                            <input type="text" className="login__input" ref={userPassword} placeholder="your password"/>
                            <button type="submit" onClick={async (e) => {
                                e.preventDefault()
                                 await fetch("http://localhost:4000/login", {
                                     method: 'POST',
                                     body: JSON.stringify({
                                         username: userName.current.value,
                                         password: userPassword.current.value
                                        }),
                                     headers: {
                                         "Content-Type": "application/json"
                                     }
                                 })
                                 return <Redirect to="/"></Redirect>
                            }} className="login-btn">
                                Submit
                            </button>

                            </form>
                        </div>

                    
                            <Link to="/signup"  className="signup-text">
                                Sign Up
                            </Link>
                        
                        </div>
                    </div>
                </>
            )
}

export default Login