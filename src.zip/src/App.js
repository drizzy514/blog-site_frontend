import './App.css';
import { Switch, Route } from 'react-router-dom';




// pages
import Login from './pages/Login/Login';
import Signup from './pages/Signup/Signup';
import Public from './routes/Public';
import Private from './routes/Private';
import Admin from './pages/Admin/Admin';
import Home from "./pages/Home/Home"

function App() {
  return (<>
        <Switch>
          <Private path='/' component ={Home} exact />
          <Public path='/login'  component={Login}  />
          <Public path='/signup'  component={Signup} />
          <Private path="/admin" component={Admin} />
        </Switch>
  </>
   
  );
}

export default App;
