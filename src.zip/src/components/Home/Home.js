function Home () {

    return (
        <>
            <h1> HOme</h1>
        </>
    )
}
export default Home